--[[
  Echoes of Aincrad - Appearance Editor (外見エディタ)  v1.0
  ------------------------------------------------------------------
  不可逆のキャラメイクを、外見(AvatarData)だけ安全にやり直すMOD。
  進行データ(レベル/所持品/クエスト等)には一切触れません。

  ホットキー(テンキー / ゲーム画面をアクティブにして押す):
    Ctrl + 1 : EXPORT  現在の外見値を設定ファイルに書き出す(選択肢つき)
               -> ue4ss/appearance_config.txt
    Ctrl + 2 : APPLY   設定ファイルの内容をセーブへ書込
               -> その後ゲーム内で通常セーブ→再ロードで反映
    Ctrl + 3 : COLORS  設定ファイルの色をその場でライブ反映(プレビュー)
    Ctrl + 4 : DUMP    現在値をコンソールに表示

  反映のしくみ:
    ・色   : Ctrl+3 でその場反映(プレビュー)。保存は Ctrl+2→通常セーブ。
    ・形   : 顔パーツ/輪郭/髪型/体型 は Ctrl+2→通常セーブ→再ロードで反映。
  ※このビルドの UE4SS は Lua 自動リロードOFF。main.lua 変更後は要ゲーム再起動。
  ※すべての UObject 操作は ExecuteInGameThread 内で実行(必須)。
--]]

local MOD = "AppEdit"
local PROBE  = "ue4ss/appedit_probe.txt"
local CONFIG = "ue4ss/appearance_config.txt"

local function log(fmt, ...) local ok,s=pcall(string.format,fmt,...); print(string.format("[%s] %s\n",MOD, ok and s or tostring(fmt))) end
local function mark(fmt, ...) local ok,s=pcall(string.format,fmt,...); s=ok and s or tostring(fmt)
    local f=io.open(PROBE,"a"); if f then f:write(os.date("%H:%M:%S ")..s.."\n"); f:flush(); f:close() end; log("%s",s) end
local function resetProbe(t) local f=io.open(PROBE,"w"); if f then f:write("=== "..t.." ===\n"); f:flush(); f:close() end end

local UEHelpers; pcall(function() UEHelpers=require("UEHelpers") end)
local function valid(o) if o==nil then return false end local ok,r=pcall(function() return o.IsValid and o:IsValid() end) return ok and r==true end

------------------------------------------------------------------
-- オブジェクト取得
------------------------------------------------------------------
local function getHero() local h=FindFirstOf("RODHeroCharacter"); if valid(h) then return h end
    if UEHelpers then local pc=UEHelpers.GetPlayerController(); if valid(pc) and valid(pc.Pawn) then return pc.Pawn end end return nil end
local function getSaveGame(ctx)
    local cdo=StaticFindObject("/Script/ROD.Default__RODGameplayStatics"); if not valid(cdo) then return nil,"CDO not found" end
    local sg; local ok,err=pcall(function() sg=cdo:GetSaveGame(ctx) end)
    if ok and valid(sg) then return sg end return nil,tostring(err) end
local function acquire()
    local hero=getHero(); local sg=getSaveGame(hero); if not valid(sg) then return hero,nil end
    local arr=sg.CharacterSaveData; local n=0; pcall(function() n=#arr end); if n==0 then return hero,sg end
    local csd=arr[1]; local av; pcall(function() av=csd.AvatarData end)
    local ap; if av then pcall(function() ap=av.AppearanceData end) end
    local parts; if av then pcall(function() parts=av.AvatarPartsData end) end
    return hero,sg,csd,av,ap,parts end
local function pushback(csd,av,ap,parts)
    pcall(function() av.AppearanceData=ap end)
    if parts then pcall(function() av.AvatarPartsData=parts end) end
    pcall(function() csd.AvatarData=av end) end

-- RemoteUnrealParam から実値を取り出す
local function unwrap(x)
    local v
    if pcall(function() v=x:get() end) and v~=nil then return v end
    if pcall(function() v=x.Value end) and v~=nil then return v end
    return tostring(x) end
local function mapKeys(m)
    local keys={}
    local ok=pcall(function() m:ForEach(function(k,_) local kv=unwrap(k); table.insert(keys, tonumber(kv) or kv) end) end)
    if (not ok or #keys==0) then pcall(function() for k,_ in pairs(m) do local kv=unwrap(k); table.insert(keys, tonumber(kv) or kv) end end) end
    table.sort(keys, function(a,b) return (tonumber(a) or 0) < (tonumber(b) or 0) end)
    return keys end

------------------------------------------------------------------
-- フィールド定義 & 日本語ラベル
------------------------------------------------------------------
local FLOAT_KEYS = {"MeshScale","Chest","Arms","ForeArms","Hands","Belly","Butts","Hips","Thighs","Legs","Feet"}
local INT_KEYS   = {"Eyebrows","Eyeline","Pupil","Nose"}
local PART_KEYS  = {"HeadID","HeadGearID","MoleID","FrecklesID"}
local BOOL_KEYS  = {"bDefaultSkinColor","bDefaultHairColor","bDefaultPupilColor","bDefaultPupilPointColor",
    "bDefaultEyebrowColor","bDefaultAccessoryColor","bDefaultEyelineColor","bDefaultBeardColor","bDefaultLipColor",
    "bDefaultUpperCostumeColor","bDefaultGlovesCostumeColor","bDefaultLowerCostumeColor"}
local COLOR_MAP = {
    SkinColor="CustomColorSkin", EyeColor="CustomColorEye", LipColor="CustomColorLip", BeardColor="CustomColorBeard",
    FaceColor1="CustomColorFaceR", FaceColor2="CustomColorFaceG", FaceColor3="CustomColorFaceB",
    HairColor1="CustomColorHairR", HairColor2="CustomColorHairG", HairColor3="CustomColorHairB",
    PupilColor1="CustomColorPupilR", PupilColor2="CustomColorPupilG", PupilColor3="CustomColorPupilB",
    UpperColor1="UpperCustomColorR", UpperColor2="UpperCustomColorG", UpperColor3="UpperCustomColorB", UpperColor4="UpperCustomColorA",
    GlovesColor1="GlovesCustomColorR", GlovesColor2="GlovesCustomColorG", GlovesColor3="GlovesCustomColorB", GlovesColor4="GlovesCustomColorA",
    LowerColor1="LowerCustomColorR", LowerColor2="LowerCustomColorG", LowerColor3="LowerCustomColorB", LowerColor4="LowerCustomColorA",
}
local COLOR_ORDER = {"SkinColor","EyeColor","LipColor","BeardColor","FaceColor1","FaceColor2","FaceColor3",
    "HairColor1","HairColor2","HairColor3","PupilColor1","PupilColor2","PupilColor3",
    "UpperColor1","UpperColor2","UpperColor3","UpperColor4","GlovesColor1","GlovesColor2","GlovesColor3","GlovesColor4",
    "LowerColor1","LowerColor2","LowerColor3","LowerColor4"}
-- パーツ番号フィールド -> DataAsset の候補マップ名
local PART_FIELD_TO_MAP = {
    HeadID="JawPartsDataAsMap", HeadGearID="HeadGearPartsDataAsMap",
    Eyebrows="EyebrowPartsDataAsMap", Eyeline="EyelinePartsDataAsMap",
    Pupil="PupilPartsDataAsMap", Nose="NosePartsDataAsMap",
    MoleID="MolePartsDataAsMap", FrecklesID="FrecklesPartsDataAsMap",
}
local LABELS = {
    Eyebrows="眉毛の形", Eyeline="目・アイラインの形", Pupil="瞳の形", Nose="鼻の形",
    MeshScale="全体の大きさ(1.0=標準)", Chest="胸の大きさ", Arms="上腕の太さ", ForeArms="前腕の太さ",
    Hands="手の大きさ", Belly="お腹のふくらみ(マイナス=引っ込む)", Butts="お尻の大きさ", Hips="腰幅",
    Thighs="太ももの太さ", Legs="ふくらはぎの太さ", Feet="足の大きさ",
    HeadID="顔の輪郭・頭のベース(顎)", HeadGearID="髪型・頭装備", MoleID="ほくろ(0=なし)", FrecklesID="そばかす(0=なし)",
    bDefaultSkinColor="肌:既定色(true)/下のSkinColorを使う(false)",
    bDefaultHairColor="髪:既定色(true)/下のHairColorを使う(false)",
    bDefaultPupilColor="瞳:既定色(true/false)", bDefaultPupilPointColor="瞳の中心:既定色(true/false)",
    bDefaultEyebrowColor="眉:既定色(true/false)", bDefaultAccessoryColor="アクセサリ:既定色(true/false)",
    bDefaultEyelineColor="アイライン:既定色(true/false)", bDefaultBeardColor="ヒゲ:既定色(true/false)",
    bDefaultLipColor="唇:既定色(true/false)", bDefaultUpperCostumeColor="上衣:既定色(true/false)",
    bDefaultGlovesCostumeColor="手袋:既定色(true/false)", bDefaultLowerCostumeColor="下衣:既定色(true/false)",
    SkinColor="肌の色", EyeColor="目・アイラインの色", LipColor="唇の色", BeardColor="ヒゲの色",
    FaceColor1="顔の色1(チーク等)", FaceColor2="顔の色2", FaceColor3="顔の色3",
    HairColor1="髪の色1(根元)", HairColor2="髪の色2(中間)", HairColor3="髪の色3(毛先)",
    PupilColor1="瞳の色1", PupilColor2="瞳の色2", PupilColor3="瞳の色3",
    UpperColor1="上衣の色1", UpperColor2="上衣の色2", UpperColor3="上衣の色3", UpperColor4="上衣の色4",
    GlovesColor1="手袋の色1", GlovesColor2="手袋の色2", GlovesColor3="手袋の色3", GlovesColor4="手袋の色4",
    LowerColor1="下衣の色1", LowerColor2="下衣の色2", LowerColor3="下衣の色3", LowerColor4="下衣の色4",
}

local function colToStr(c) local r,g,b,a=0,0,0,0
    pcall(function() r=c.R; g=c.G; b=c.B; a=c.A end)
    return string.format("%.3f,%.3f,%.3f,%.3f", r,g,b,a) end

-- DataAsset から各パーツの候補ID文字列を集める
local function gatherCandidates()
    local out={}
    local da=FindFirstOf("RODAvatarCustomizeDataAsset")
    if not valid(da) then return out, false end
    for field,mapname in pairs(PART_FIELD_TO_MAP) do
        local m; pcall(function() m=da[mapname] end)
        if m then local keys=mapKeys(m); if #keys>0 then out[field]=table.concat(keys, ",") end end
    end
    return out, true end

------------------------------------------------------------------
-- EXPORT
------------------------------------------------------------------
local function cmdExport()
    resetProbe("EXPORT")
    local hero,sg,csd,av,ap,parts = acquire()
    if not (ap and parts) then mark("取得失敗(セーブ/キャラ未ロード?)"); return end
    local cand, daOK = gatherCandidates()
    local L={}; local function w(s) table.insert(L,s) end
    local function lblc(k, extra) -- 行末コメント(ラベル + 選択肢)
        local d=LABELS[k] or ""
        local c=cand[k]
        local s="  # "..d
        if c then s=s.."  選択肢: "..c end
        if extra then s=s.."  "..extra end
        return s
    end
    local hn="?"; pcall(function() hn=av.HeroName:ToString() end)
    w("# ===== Echoes of Aincrad 外見エディタ 設定ファイル =====")
    w("# 値を編集 → ゲーム内で Ctrl+2(保存) → 通常セーブ → 再ロードで反映")
    w("# 色は Ctrl+3 でその場プレビュー可(保存は Ctrl+2)")
    w("# 各行『選択肢:』が選べる番号。色は R,G,B,A (0.0〜1.0)")
    w("# 変えたくない行は消してOK(現状維持)")
    if not daOK then w("# ※パーツ選択肢を取得できませんでした(ゲーム内でキャラ表示中に Ctrl+1 推奨)") end
    w("# キャラ名: "..hn)
    w("")
    w("# ---------- 顔パーツ(番号で選択) ----------")
    for _,k in ipairs(INT_KEYS) do local v=0; pcall(function() v=ap[k] end); w(string.format("%s=%d%s", k, math.floor(v+0.5), lblc(k))) end
    w("")
    w("# ---------- 輪郭・髪型・ほくろ・そばかす(番号で選択) ----------")
    for _,k in ipairs(PART_KEYS) do local v=0; pcall(function() v=parts[k] end); w(string.format("%s=%d%s", k, math.floor(v+0.5), lblc(k))) end
    w("")
    w("# ---------- 体型・大きさ(1.0が標準。0.5〜1.5程度) ----------")
    for _,k in ipairs(FLOAT_KEYS) do local v=0; pcall(function() v=ap[k] end); w(string.format("%s=%.4f%s", k, v, lblc(k))) end
    w("")
    w("# ---------- 色を既定/カスタムどちらにするか(true=ゲーム既定 / false=下の色) ----------")
    for _,k in ipairs(BOOL_KEYS) do local v=true; pcall(function() v=ap[k] end); w(string.format("%s=%s%s", k, tostring(v), lblc(k))) end
    w("")
    w("# ---------- 色 (R,G,B,A / 例: 1.0,0.15,0.15,1.0) ----------")
    for _,name in ipairs(COLOR_ORDER) do
        local field=COLOR_MAP[name]; local c; pcall(function() c=ap[field] end)
        if c then w(string.format("%s=%s%s", name, colToStr(c), lblc(name))) end
    end
    local f=io.open(CONFIG,"w")
    if f then f:write(table.concat(L,"\n")); f:close(); mark("EXPORT 完了 -> %s", CONFIG)
    else mark("EXPORT 失敗: ファイルを開けません") end
    mark("DONE export")
end

------------------------------------------------------------------
-- APPLY
------------------------------------------------------------------
local function parseConfig()
    local t={}; local f=io.open(CONFIG,"r"); if not f then return nil end
    for line in f:lines() do
        local s=line:gsub("^%s+",""):gsub("%s+$","")
        if s~="" and s:sub(1,1)~="#" then
            local k,v=s:match("^([%w_]+)%s*=%s*(.+)$")
            if k and v then v=v:gsub("%s*#.*$",""):gsub("%s+$",""); if v~="" then t[k]=v end end
        end
    end
    f:close(); return t end
local function isIn(list,key) for _,k in ipairs(list) do if k==key then return true end end return false end
local function parseColor(v)
    local r,g,b,a=v:match("([%-%d%.]+)%s*,%s*([%-%d%.]+)%s*,%s*([%-%d%.]+)%s*,%s*([%-%d%.]+)")
    if not r then r,g,b=v:match("([%-%d%.]+)%s*,%s*([%-%d%.]+)%s*,%s*([%-%d%.]+)"); a="1.0" end
    return tonumber(r),tonumber(g),tonumber(b),tonumber(a) end

local function cmdApply()
    resetProbe("APPLY")
    local cfg=parseConfig()
    if not cfg then mark("設定ファイルが読めません(先に Ctrl+1)"); return end
    local hero,sg,csd,av,ap,parts = acquire()
    if not (ap and parts and valid(sg)) then mark("取得失敗"); return end
    local cnt=0
    for k,v in pairs(cfg) do
        local done=false
        if isIn(FLOAT_KEYS,k) then local n=tonumber(v); if n then pcall(function() ap[k]=n end); done=true end
        elseif isIn(INT_KEYS,k) then local n=tonumber(v); if n then pcall(function() ap[k]=math.floor(n+0.5) end); done=true end
        elseif isIn(PART_KEYS,k) then local n=tonumber(v); if n then pcall(function() parts[k]=math.floor(n+0.5) end); done=true end
        elseif isIn(BOOL_KEYS,k) then local b=(v=="true" or v=="1"); pcall(function() ap[k]=b end); done=true
        elseif COLOR_MAP[k] then local field=COLOR_MAP[k]; local r,g,b,a=parseColor(v)
            if r then local c; pcall(function() c=ap[field] end)
                if c then pcall(function() c.R=r; c.G=g; c.B=b; c.A=a end); pcall(function() ap[field]=c end); done=true end end
        end
        if done then cnt=cnt+1 else mark("skip(未知): %s", k) end
    end
    pushback(csd,av,ap,parts)
    mark("APPLY 完了: %d 項目を書込 → 通常セーブ→再ロードで反映", cnt)
    mark("DONE apply")
end

------------------------------------------------------------------
-- COLORS (ライブ反映)
------------------------------------------------------------------
local function collectMeshes(hero)
    local meshes={}; local seen={}
    local function add(name,m) if valid(m) then local fn; pcall(function() fn=m:GetFullName() end)
        if fn and not seen[fn] then seen[fn]=true; table.insert(meshes,{name=name,comp=m}) end end end
    for _,pn in ipairs({"Mesh","UpperMesh","LowerMesh","GlovesMesh","EyebrowsMesh","EyelineMesh","PupilMesh","NoseMesh","HeadGearMesh"}) do
        local m; pcall(function() m=hero[pn] end); add(pn,m) end
    local all=FindAllOf("SkeletalMeshComponent")
    if all then local hn=hero:GetFullName()
        for _,m in ipairs(all) do if valid(m) then local o; pcall(function() o=m:GetOwner() end)
            if valid(o) and o:GetFullName()==hn then add("auto",m) end end end end
    return meshes end
local function cmdLiveColors()
    resetProbe("LIVECOLORS")
    local cfg=parseConfig(); if not cfg then mark("config読めず(先にCtrl+1)"); return end
    local hero=getHero(); if not valid(hero) then mark("hero無効"); return end
    local meshes=collectMeshes(hero); local cnt=0
    for cfgKey,field in pairs(COLOR_MAP) do
        local v=cfg[cfgKey]
        if v then local r,g,b=parseColor(v)
            if r then local vec; pcall(function() vec={X=r,Y=g,Z=b} end)
                for _,mm in ipairs(meshes) do pcall(function() mm.comp:SetVectorParameterValueOnMaterials(FName(field), vec) end) end
                cnt=cnt+1 end end
    end
    mark("色ライブ反映: %d色 を %dメッシュへ(その場で色が変わります/保存はCtrl+2)", cnt, #meshes)
    mark("DONE livecolors")
end

------------------------------------------------------------------
-- DUMP
------------------------------------------------------------------
local function cmdDump()
    resetProbe("DUMP")
    local hero,sg,csd,av,ap,parts = acquire()
    mark("hero=%s savegame=%s", valid(hero) and "OK" or "NG", valid(sg) and "OK" or "NG")
    if not (ap and parts) then mark("取得失敗"); return end
    local hn="?"; pcall(function() hn=av.HeroName:ToString() end); log("HeroName=%s", hn)
    for _,k in ipairs(INT_KEYS) do local v="?"; pcall(function() v=tostring(ap[k]) end); log("  %s=%s (%s)",k,v,LABELS[k] or "") end
    for _,k in ipairs(PART_KEYS) do local v="?"; pcall(function() v=tostring(parts[k]) end); log("  %s=%s (%s)",k,v,LABELS[k] or "") end
    for _,k in ipairs(FLOAT_KEYS) do local v="?"; pcall(function() v=tostring(ap[k]) end); log("  %s=%s",k,v) end
    mark("DONE dump")
end

------------------------------------------------------------------
local function bind(key, fn, name)
    RegisterKeyBind(key, {ModifierKey.CONTROL}, function()
        ExecuteInGameThread(function()
            local ok,err=pcall(fn); if not ok then mark("Lua ERROR in %s: %s", name, tostring(err)) end
        end)
    end)
end
bind(Key.NUM_ONE,   cmdExport,     "export")
bind(Key.NUM_TWO,   cmdApply,      "apply")
bind(Key.NUM_THREE, cmdLiveColors, "livecolors")
bind(Key.NUM_FOUR,  cmdDump,       "dump")

log("Appearance Editor v1.0 loaded. Ctrl+ テンキー 1:出力 2:保存 3:色ライブ 4:確認")
